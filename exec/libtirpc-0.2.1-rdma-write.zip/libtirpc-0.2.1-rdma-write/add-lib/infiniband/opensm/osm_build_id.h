define osm_build_type "free"
